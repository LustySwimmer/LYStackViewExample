//
//  LYImageView.h
//  LYBridgeExample
//
//  Created by 吕师 on 16/7/7.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XXNibBridge.h"

@interface LYImageView : UIView<XXNibBridge>

/** 标题 */
@property (nullable,nonatomic, copy)IBInspectable NSString *title;
/** 图片 */
@property (nullable,nonatomic, strong)IBInspectable UIImage *image;

@end
