//
//  AppDelegate.h
//  LYBridgeExample
//
//  Created by 吕师 on 16/7/7.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

