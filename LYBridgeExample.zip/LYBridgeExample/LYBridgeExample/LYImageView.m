//
//  LYImageView.m
//  LYBridgeExample
//
//  Created by 吕师 on 16/7/7.
//  Copyright © 2016年 XiangChaoKanKan. All rights reserved.
//

#import "LYImageView.h"

#define RANDOMCOLOR [UIColor colorWithRed:arc4random_uniform(256)/255.0 green:arc4random_uniform(256)/255.0 blue:arc4random_uniform(256)/255.0 alpha:1.0f]

@interface LYImageView ()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation LYImageView

- (void)awakeFromNib {
//    self.backgroundColor = RANDOMCOLOR;
}

- (void)setTitle:(NSString *)title {
    _title = [title copy];
    self.titleLabel.text = title;
}

- (void)setImage:(UIImage *)image {
    _image = image;
    self.imageView.image = image;
}

@end
